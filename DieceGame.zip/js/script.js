        let layer1 = document.getElementById("player1");
        let layer2 = document.getElementById("player2");

       

       function editName(){
        let name1 = prompt("Enter player 1 name");
        let name2 = prompt("Enter Player 2 name");
            layer1.innerHTML = name1;
            layer2.innerHTML = name2;
        }

        function roll(){
            setTimeout(function(){
                var random1 = Math.floor(Math.random() * 6) + 1;
                var random2 = Math.floor(Math.random() * 6) + 1;

                document.querySelector('.img1').setAttribute("src","img/dice"+random1+".png");
                document.querySelector('.img2').setAttribute("src","img/dice"+random2+".png");

                if(random1 === random2){
                    document.querySelector('h1').innerHTML = "DRAW <span>😞😞😞<span>";
                }else if(random1 > random2){
                    document.querySelector('h1').innerHTML = "Player 1 Winner <span> 😀🥳🥳🥳 </span>";
                }else{
                    document.querySelector('h1').innerHTML = "Player 2 Winner <span> 🥳😀🥳🥳 </span>";
                }

            },2500);
        }